<?php if (isset($component)) { $__componentOriginala66aeaaa9355053503ba20a6fc0977fe = $component; } ?>
<?php $component = App\View\Components\ViewerLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('viewer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ViewerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($currentChapter->name); ?> <?php $__env->endSlot(); ?>
    <?php
        $paginado = request()->route('reader_type');
    ?>
    <div id="viewer">
        <section class="view__options">
            <div class="view__col view__left">
                <div class="view__title">
                    <a href="<?php echo e($manga->url()); ?>" class="view__back">
                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13.6668 6.16671H3.52516L8.1835 1.50837L7.00016 0.333374L0.333496 7.00004L7.00016 13.6667L8.17516 12.4917L3.52516 7.83337H13.6668V6.16671Z" fill="white"/>
                        </svg>
                    </a>
                    <h2><?php echo e($manga->name); ?>: <?php echo e($currentChapter->name); ?></h2>
                </div>
            </div>
            <div class="view__col view__center">
                <div class="view__select chapter__list">
                    <select id="slct_chapter_list" placeholder="Capítulos..." autocomplete="off">
                        <option value="">Capitulos...</option>
                        <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($chapter->slug); ?>" <?php echo e(($chapter_slug == $chapter->slug)? 'selected' : null); ?> data-url="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $chapter->slug
                            ])); ?>"><?php echo e(Str::limit($chapter->name, 18)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if($currentChapter->type == "manga"): ?>
                    <div class="view__select chapter__reader_type">
                        <select id="slct_reader_type" placeholder="Tipo de lector" autocomplete="off">
                            <option value="0">Tipo de lector</option>
                            <option value="1" data-url="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $currentChapter->slug
                            ])); ?>" <?php echo e((!$paginado)? "selected" : null); ?>>Cascada</option>
                            <option value="2" data-url="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $currentChapter->slug,
                                'reader_type' => "paginado"
                            ])); ?>" <?php echo e(($paginado)? "selected" : null); ?>>Paginado</option>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="view__select chapter__reader_size">
                    <select id="slct_reader_size" placeholder="Tamaño" autocomplete="off">
                        <option value="0">Tamaño</option>
                        <option value="1">Ancho</option>
                        <option value="2" selected>Ajustado</option>
                    </select>
                </div>
                <?php if($currentChapter->type == "novel"): ?>
                    <div class="view__select chapter__font_size">
                        <select id="slct_font_size" placeholder="Tamaño de letra" autocomplete="off">
                            <option value="0">Tamaño de letra</option>
                            <option value="14" >14px</option>
                            <option value="16" selected>16px</option>
                            <option value="18">18px</option>
                            <option value="20">20px</option>
                            <option value="22">22px</option>
                            <option value="24">24px</option>
                            <option value="26">26px</option>
                        </select>
                    </div>
                <?php endif; ?>
            </div>
            <div class="view__col view__right">
                <div class="view__buttons">
                    <?php if(isset($prev_chapter->slug)): ?>
                        <a href="<?php echo e(route('chapter_viewer.index', [
                            'manga_slug' => $manga->slug,
                            'chapter_slug' => $prev_chapter->slug
                        ])); ?>">Anterior</a>
                    <?php endif; ?>
                    <?php if(isset($next_chapter->slug)): ?>
                        <a href="<?php echo e(route('chapter_viewer.index', [
                            'manga_slug' => $manga->slug,
                            'chapter_slug' => $next_chapter->slug
                        ])); ?>">Siguiente</a>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
            $ad_9 = config('app.ads_9');
        ?>
        <?php if($ad_9): ?>
            <div class="vealo">
                <?php echo $ad_9; ?>

            </div>
        <?php endif; ?>
        <section class="view__reader">
            <?php if($currentChapter->type == "novel"): ?>
                <div class="view__colors">
                    <div class="color__item">
                        <div class="color__field bg__field">
                            <label for="choose_background">Cambiar fondo</label>
                            <input type="text" class="coloris input_bg_color" id="choose_background" value="rgb(255, 0, 0)">
                        </div>
                    </div>
                    <div class="color__item">
                        <div class="color__field text__field">
                            <label for="choose_color">Cambiar color</label>
                            <input type="text" class="coloris input_font_color" id="choose_color" value="rgb(255, 0, 0)">
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($currentChapter->type == "manga"): ?>
                <?php if(isset($paginado)): ?>
                    <div class="view__paged">
                        <?php if(isset($prev_paged)): ?>
                            <a href="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $currentChapter->slug,
                                'reader_type' => "paginado",
                                'current_page' => $prev_paged
                            ])); ?>" class="paged__item paged__prev paged__link">Anterior</a>
                        <?php else: ?>
                            <?php if(isset($next_paged)): ?>
                                <button class="paged__item paged__disabled">Anterior</button>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(isset($total_pages)): ?>
                            <div class="view__select chapter__paged_list">
                                <select id="slct_paged_list" placeholder="Tamaño" autocomplete="off">
                                    <option value="0">Tamaño</option>
                                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                        <option value="<?php echo e($i); ?>" data-url="<?php echo e(route('chapter_viewer.index', [
                                            'manga_slug' => $manga->slug,
                                            'chapter_slug' => $currentChapter->slug,
                                            'reader_type' => "paginado",
                                            'current_page' => $i
                                        ])); ?>" <?php echo e((isset($current_page) && $current_page == $i)? "selected": null); ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>  
                                </select>
                            </div>
                        <?php endif; ?>
                        <?php if(isset($next_paged)): ?>
                            <a href="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $currentChapter->slug,
                                'reader_type' => "paginado",
                                'current_page' => $next_paged
                            ])); ?>" class="paged__item paged__next paged__link">Siguiente</a>
                        <?php else: ?>
                            <?php if(isset($prev_paged)): ?>
                                <button class="paged__item paged__disabled">Siguiente</button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <div class="view__content<?php echo e(($currentChapter->type == "novel")? ' view__novel' : null); ?>">
                <?php switch($currentChapter->type):
                    case ("novel"): ?>
                        <?php echo $content; ?>

                    <?php break; ?>
                    <?php case ("manga"): ?>
                        <?php if(isset($images) && !empty($images)): ?>
                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="reader__item">
                                    <img src="<?php echo e(Storage::disk($currentChapter->disk)->url($image)); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>    
                    <?php break; ?>
                    <?php default: ?>
                        
                <?php endswitch; ?>
            </div>
            <?php if($currentChapter->type == "novel"): ?>
                <div class="view__colors">
                    <div class="color__item">
                        <div class="color__field bg__field">
                            <label for="choose_background_bottom">Cambiar fondo</label>
                            <input type="text" class="coloris input_bg_color" id="choose_background_bottom" value="rgb(255, 0, 0)">
                        </div>
                    </div>
                    <div class="color__item">
                        <div class="color__field text__field">
                            <label for="choose_color_bottom">Cambiar color</label>
                            <input type="text" class="coloris input_font_color" id="choose_color_bottom" value="rgb(255, 0, 0)">
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($currentChapter->type == "manga"): ?>
                <?php if(isset($paginado)): ?>
                    <div class="view__paged">
                        <?php if(isset($prev_paged)): ?>
                            <a href="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $currentChapter->slug,
                                'reader_type' => "paginado",
                                'current_page' => $prev_paged
                            ])); ?>" class="paged__item paged__prev paged__link">Anterior</a>
                        <?php else: ?>
                            <?php if(isset($next_paged)): ?>
                                <button class="paged__item paged__disabled">Anterior</button>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(isset($total_pages)): ?>
                            <div class="view__select chapter__paged_list">
                                <select id="slct_paged_list_bottom" placeholder="Tamaño" autocomplete="off">
                                    <option value="0">Tamaño</option>
                                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                        <option value="<?php echo e($i); ?>" data-url="<?php echo e(route('chapter_viewer.index', [
                                            'manga_slug' => $manga->slug,
                                            'chapter_slug' => $currentChapter->slug,
                                            'reader_type' => "paginado",
                                            'current_page' => $i
                                        ])); ?>" <?php echo e((isset($current_page) && $current_page == $i)? "selected": null); ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>  
                                </select>
                            </div>
                        <?php endif; ?>
                        <?php if(isset($next_paged)): ?>
                            <a href="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $currentChapter->slug,
                                'reader_type' => "paginado",
                                'current_page' => $next_paged
                            ])); ?>" class="paged__item paged__next paged__link">Siguiente</a>
                        <?php else: ?>
                            <?php if(isset($prev_paged)): ?>
                                <button class="paged__item paged__disabled">Siguiente</button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </section>
        <?php
            $ad_10 = config('app.ads_10');
        ?>
        <?php if($ad_10): ?>
            <div class="vealo">
                <?php echo $ad_10; ?>

            </div>
        <?php endif; ?>
        <section class="view__options bottom">
            <div class="view__col view__left">
                <div class="view__title">
                    <a href="<?php echo e($manga->url()); ?>" class="view__back">
                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13.6668 6.16671H3.52516L8.1835 1.50837L7.00016 0.333374L0.333496 7.00004L7.00016 13.6667L8.17516 12.4917L3.52516 7.83337H13.6668V6.16671Z" fill="white"/>
                        </svg>
                    </a>
                    <h2><?php echo e($manga->name); ?>: <?php echo e($currentChapter->name); ?></h2>
                </div>
            </div>
            <div class="view__col view__center">
                <div class="view__select chapter__list">
                    <select id="slct_chapter_list_bottom" placeholder="Capítulos..." autocomplete="off">
                        <option value="">Capitulos...</option>
                        <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($chapter->slug); ?>" <?php echo e(($chapter_slug == $chapter->slug)? 'selected' : null); ?> data-url="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $chapter->slug
                            ])); ?>"><?php echo e(Str::limit($chapter->name, 18)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if($currentChapter->type == "manga"): ?>
                    <div class="view__select chapter__reader_type">
                        <select id="slct_reader_type_bottom" placeholder="Tipo de lector" autocomplete="off">
                            <option value="0">Tipo de lector</option>
                            <option value="1" data-url="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $currentChapter->slug
                            ])); ?>" <?php echo e((!$paginado)? "selected" : null); ?>>Cascada</option>
                            <option value="2" data-url="<?php echo e(route('chapter_viewer.index', [
                                'manga_slug' => $manga->slug,
                                'chapter_slug' => $currentChapter->slug,
                                'reader_type' => "paginado"
                            ])); ?>" <?php echo e(($paginado)? "selected" : null); ?>>Paginado</option>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="view__select chapter__reader_size">
                    <select id="slct_reader_size_bottom" placeholder="Tamaño" autocomplete="off">
                        <option value="0">Tamaño</option>
                        <option value="1">Ancho</option>
                        <option value="2" selected>Ajustado</option>
                    </select>
                </div>
                <?php if($currentChapter->type == "novel"): ?>
                    <div class="view__select chapter__font_size">
                        <select id="slct_font_size_bottom" placeholder="Tamaño de letra" autocomplete="off">
                            <option value="0">Tamaño de letra</option>
                            <option value="14" >14px</option>
                            <option value="16" selected>16px</option>
                            <option value="18">18px</option>
                            <option value="20">20px</option>
                            <option value="22">22px</option>
                            <option value="24">24px</option>
                            <option value="26">26px</option>
                        </select>
                    </div>
                <?php endif; ?>
            </div>
            <div class="view__col view__right">
                <div class="view__buttons">
                    <?php if(isset($prev_chapter->slug)): ?>
                        <a href="<?php echo e(route('chapter_viewer.index', [
                            'manga_slug' => $manga->slug,
                            'chapter_slug' => $prev_chapter->slug
                        ])); ?>">Anterior</a>
                    <?php endif; ?>
                    <?php if(isset($next_chapter->slug)): ?>
                        <a href="<?php echo e(route('chapter_viewer.index', [
                            'manga_slug' => $manga->slug,
                            'chapter_slug' => $next_chapter->slug
                        ])); ?>">Siguiente</a>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
    <?php if($currentChapter->type == "novel"): ?>
        <script>
            const inputBgColors = document.querySelectorAll('.input_bg_color');
            Coloris({
                el: '.coloris',
                themeMode: 'dark',
                swatches: [
                    '#141414'
                ],
                onChange: (color, input) =>{
                    const fieldColors = document.querySelectorAll('.view__colors .bg__field .clr-field');
                    fieldColors.forEach(item => {
                        item.style.color = color;
                    });
                    inputBgColors.forEach(item => {
                        item.value = color;
                        item.style.color = color;
                    });

                    const bdy = document.querySelector('#viewer .view__content');
                    localStorage.setItem('content_body_color', color);
                    bdy.style.backgroundColor = color;
                }
            });

            const inputColors = document.querySelectorAll('.input_font_color');
            Coloris.setInstance('.input_font_color', {
                // Focus the color value input when the color picker dialog is opened.
                focusInput: true,

                // Select and focus the color value input when the color picker dialog is opened.
                selectInput: true,
                onChange: (color, input) =>{
                    const fieldColors = document.querySelectorAll('.view__colors .text__field .clr-field');
                    fieldColors.forEach(item => {
                        item.style.color = color;
                    });
                    inputColors.forEach(item => {
                        item.value = color;
                        item.style.color = color;
                    });
                    const contentColor = document.querySelector('#viewer .view__content');
                    localStorage.setItem('content_font_color', color);
                    contentColor.style.color = color;
                }
            });
        </script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala66aeaaa9355053503ba20a6fc0977fe)): ?>
<?php $component = $__componentOriginala66aeaaa9355053503ba20a6fc0977fe; ?>
<?php unset($__componentOriginala66aeaaa9355053503ba20a6fc0977fe); ?>
<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/viewer.blade.php ENDPATH**/ ?>