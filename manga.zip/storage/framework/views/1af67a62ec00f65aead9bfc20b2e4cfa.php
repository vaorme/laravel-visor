<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <aside class="filter">
        <form action="" class="filter__form">
            <div class="filter__widget">
                <h2 class="widget__title">Filtros</h2>
                <div class="widget__content">
                    <?php if($types->isNotEmpty()): ?>
                        <div class="widget__item">
                            <select name="filter_type" id="select-type">
                                <option value="" selected>Tipo</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <?php if($demographics->isNotEmpty()): ?>
                        <div class="widget__item">
                            <select name="filter_demography" id="select-demography">
                                <option value="" selected>Demografia</option>
                                <?php $__currentLoopData = $demographics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <?php if($bookStatus->isNotEmpty()): ?>
                        <div class="widget__item">
                            <select name="filter_bookstatus" id="select-bookstatus">
                                <option value="" selected>Estado</option>
                                <?php $__currentLoopData = $bookStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <button class="filter__button" type="submit">Filtrar</button>
                </div>
            </div>
            <?php if($categories->isNotEmpty()): ?>
                <div class="filter__widget filter__categories">
                    <h2 class="widget__title">Categorías</h2>
                    <div class="widget__content">
                        <div class="widget__scl">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label for="cck-<?php echo e($key); ?>">
                                    <input type="checkbox" name="filter_categories[]" value="<?php echo e($item->slug); ?>" id="cck-<?php echo e($key); ?>">
                                    <div class="checkbox">
                                        <div class="check__field"></div>
                                        <div class="check__name"><?php echo e($item->name); ?></div>
                                    </div>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="filter__widget filter__categories">
                    <h2 class="widget__title">Excluir categorías</h2>
                    <div class="widget__content">
                        <div class="widget__scl">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label for="cck-<?php echo e($key); ?>">
                                    <input type="checkbox" name="filter_excategories[]" value="<?php echo e($item->slug); ?>" id="cck-<?php echo e($key); ?>">
                                    <div class="checkbox">
                                        <div class="check__field"></div>
                                        <div class="check__name"><?php echo e($item->name); ?></div>
                                    </div>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </form>
    </aside>
    <section class="library">
        <div class="manga">
            <?php if($list->isNotEmpty()): ?>
                <div class="manga__list">
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal1404d421185503a5253acba2bee1c433 = $component; } ?>
<?php $component = App\View\Components\MangaLoopItem::resolve(['item' => $item] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('manga-loop-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MangaLoopItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1404d421185503a5253acba2bee1c433)): ?>
<?php $component = $__componentOriginal1404d421185503a5253acba2bee1c433; ?>
<?php unset($__componentOriginal1404d421185503a5253acba2bee1c433); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="empty">No hay elementos para mostrar</div>
            <?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/library.blade.php ENDPATH**/ ?>