<?php echo e($slot); ?>

<?php /**PATH D:\Spaces\LARAVEL\manga\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>