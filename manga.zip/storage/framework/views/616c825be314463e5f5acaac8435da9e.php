<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Manga | Crear <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal2204861c4666ea1210f99ef4fed14180 = $component; } ?>
<?php $component = App\View\Components\Admin\Bar::resolve(['backTo' => route('manga.index')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Bar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2204861c4666ea1210f99ef4fed14180)): ?>
<?php $component = $__componentOriginal2204861c4666ea1210f99ef4fed14180; ?>
<?php unset($__componentOriginal2204861c4666ea1210f99ef4fed14180); ?>
<?php endif; ?>
    <div class="frmo fm-manga fm-create">
        <form action="<?php echo e(route('manga.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="errores">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="main">
                <div class="section cols head">
                    <div class="item name">
                        <label for="m-name">Name</label>
                        <input type="text" name="name" id="m-name">
                    </div>
                    <div class="item slug">
                        <label for="m-slug">Slug</label>
                        <input type="text" name="slug" id="m-slug">
                    </div>
                    <div class="item alt-name">
                        <label for="m-altname">Alternative Name</label>
                        <input type="text" name="alternative_name" id="m-altname">
                    </div>
                </div>
                <div class="section cols description">
                    <div class="item">
                        <label>Description</label>
                        <textarea name="description" id="m-description" cols="30" rows="5"></textarea>
                    </div>
                </div>
                <div class="section cols dates">
                    <div class="item">
                        <label>Capítulo nuevo</label>
                        <div class="dates__select">
                            <select name="new_chapters_time" id="ch-chapter-time">
                                <option value="">Seleccionar</option>
                                <option value="day">Diario</option>
                                <option value="week">Semanal</option>
                                <option value="month">Mensual</option>
                            </select>
                        </div>
                    </div>
                    <div class="item">
                        <label for="ch-date">Fecha</label>
                        <input type="text" name="new_chapters_date" id="ch-date" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="sidebar">
                <div class="module options grid grid-cols-5 gap-4">
                    <div class="item col-span-3">
                        <select name="status" id="m-status">
                            <option value="published" selected>Publicado</option>
                            <option value="draft">Borrador</option>
                            <option value="private">Privado</option>
                        </select>
                    </div>
                    <div class="item delete col-span-2">
                        <a href="<?php echo e(route('manga.index')); ?>">Volver</a>
                    </div>
                    <div class="item save col-span-5">
                        <button type="submit">Crear</button>
                    </div>
                </div>
                <div class="module cover">
                    <div class="dropzone">
                        <div id="choose">
                            <div class="preview">
                                <img src="" alt="" class="image-preview">
                            </div>
                            <p class="text-drop">Elegir portada</p>
                        </div>
                        <input type="file" name="featured_image" id="m-image" accept="image/*" hidden>
                    </div>
                </div>
                <div class="module published">
                    <div class="group">
                        <label class="group-label">Publicado por</label>
                        <select name="user_id" id="m-published">
                            <option value="" selected disabled>Seleccionar usuario</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(($user->id == Auth::id())? 'selected': ''); ?>><?php echo e($user->username); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="module categories">
                    <div class="group">
                        <label class="group-label">Categorías</label>
                        <div class="in-field">
                            <select name="categories[]" id="m-categories" multiple>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="module tags">
                    <div class="group">
                        <label class="group-label">Tags</label>
                        <div class="in-field">
                            <input type="text" name="tags" id="m-tags">
                        </div>
                    </div>
                </div>
                <div class="module release_date">
                    <div class="group">
                        <label class="group-label">Fecha de lanzamiento</label>
                        <input type="text" name="release_date" id="field-date" autocomplete="off">
                    </div>
                </div>
                <div class="module manga_type">
                    <div class="group">
                        <label class="group-label">Tipo de manga</label>
                        <select name="type_id" id="m-mangatype">
                            <option value="" selected disabled>Seleccionar</option>
                            <?php $__currentLoopData = $manga_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="module manga_status">
                    <div class="group">
                        <label class="group-label">Manga estado</label>
                        <select name="book_status_id" id="m-bookstatus">
                            <option value="" selected disabled>Seleccionar</option>
                            <?php $__currentLoopData = $manga_book_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="module manga_demography">
                    <div class="group">
                        <label class="group-label">Manga demografia</label>
                        <select name="demography_id" id="m-demography">
                            <option value="" selected disabled>Seleccionar</option>
                            <?php $__currentLoopData = $manga_demographies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/admin/manga/create.blade.php ENDPATH**/ ?>