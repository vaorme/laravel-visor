<footer class="footer">
    <div class="footer__copy">
        <p>&copy; 2023 - Nartag</p>
    </div>
</footer>
<?php
    $insertFooter = config('app.footer');
?>
<?php if($insertFooter): ?>
    <?php echo $insertFooter; ?>

<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/components/footer.blade.php ENDPATH**/ ?>