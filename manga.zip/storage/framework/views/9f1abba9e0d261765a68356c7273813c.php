<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Publicidad <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal636e3f15d46e2614ee296f3016d363dc = $component; } ?>
<?php $component = App\View\Components\Admin\Nav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Nav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <li class="<?php echo e((request()->is('controller/settings/ads')) ? 'active' : ''); ?>"><a href="<?php echo e(route('settings.ads.index')); ?>">Publicidad</a></li>
        <li class="<?php echo e((request()->is('controller/settings/seo')) ? 'active' : ''); ?>"><a href="<?php echo e(route('settings.seo.index')); ?>">SEO</a></li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal636e3f15d46e2614ee296f3016d363dc)): ?>
<?php $component = $__componentOriginal636e3f15d46e2614ee296f3016d363dc; ?>
<?php unset($__componentOriginal636e3f15d46e2614ee296f3016d363dc); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2204861c4666ea1210f99ef4fed14180 = $component; } ?>
<?php $component = App\View\Components\Admin\Bar::resolve(['title' => 'Publicidad'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Bar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2204861c4666ea1210f99ef4fed14180)): ?>
<?php $component = $__componentOriginal2204861c4666ea1210f99ef4fed14180; ?>
<?php unset($__componentOriginal2204861c4666ea1210f99ef4fed14180); ?>
<?php endif; ?>
    <div class="settings flex flex-wrap">
        <div class="contain w-full">
            <?php if(Session::has('success')): ?>
                <div class="alertas success">
                    <div class="box">
                        <p><?php echo \Session::get('success'); ?></p>
                    </div>
                </div>
                <script>
                    let alerta = document.querySelector('.alertas');
                    setTimeout(() => {
                        alerta.remove();
                    }, 2000);
                </script>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
                <div class="alertas error">
                    <div class="box">
                        <p><?php echo \Session::get('error'); ?></p>
                    </div>
                </div>
                <script>
                    let alerta = document.querySelector('.alertas');
                    setTimeout(() => {
                        alerta.remove();
                    }, 2000);
                </script>
            <?php endif; ?>
        </div>
        <section class="settings__contain w-full">
            <div class="frmo">
                <form action="<?php echo e(isset($setting)? route('settings.ads.update') : route('settings.ads.store')); ?>" class="form" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($setting)): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php else: ?>
                        <?php echo method_field('POST'); ?>
                    <?php endif; ?>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #1</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-1.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_1" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_1', $setting->ads_1) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #2</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-2.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_2" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_2', $setting->ads_2) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #3</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-3.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_3" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_3', $setting->ads_3) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #4</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-4.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_4" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_4', $setting->ads_4) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #5</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-5.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_5" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_5', $setting->ads_5) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #6</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-6.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_6" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_6', $setting->ads_6) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #7</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-7.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_7" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_7', $setting->ads_7) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #8</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-8.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_8" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_8', $setting->ads_8) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #9</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-9.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_9" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_9', $setting->ads_9) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #10</label>
                            <p>Ubicación <a href="<?php echo e(asset('storage/images/ads/ad-10.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_10" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_10', $setting->ads_10) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #11</label>
                            <p>Ubicación abajo<a href="<?php echo e(asset('storage/images/ads/ad-11.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_11" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_10', $setting->ads_11) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #12</label>
                            <p>Ubicación arriba <a href="<?php echo e(asset('storage/images/ads/ad-11.jpg')); ?>" target="_blank">EJEMPLO</a></p>
                        </div>
                        <textarea name="ads_12" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_10', $setting->ads_12) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #13</label>
                            <p>Sin ubicación</p>
                        </div>
                        <textarea name="ads_13" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_10', $setting->ads_13) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #14</label>
                            <p>Sin ubicación</p>
                        </div>
                        <textarea name="ads_10" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_10', $setting->ads_14) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <div class="group__label">
                            <label>ADS #15</label>
                            <p>Sin ubicación</p>
                        </div>
                        <textarea name="ads_15" cols="30" rows="6"><?php echo e(isset($setting)? old('ads_10', $setting->ads_15) : ''); ?></textarea>
                    </div>
                    
                    <div class="errores">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="botn success">Guardar</button>
                </form>
            </div>
        </section>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/admin/settings/ads.blade.php ENDPATH**/ ?>