<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Manga | Tipos <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal636e3f15d46e2614ee296f3016d363dc = $component; } ?>
<?php $component = App\View\Components\Admin\Nav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Nav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <li class="<?php echo e((request()->is('controller/manga/type')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manga_types.index')); ?>">Tipos</a></li>
        <li class="<?php echo e((request()->is('controller/manga/status')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manga_book_status.index')); ?>">Estados</a></li>
        <li class="<?php echo e((request()->is('controller/manga/demography')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manga_demography.index')); ?>">Demografia</a></li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal636e3f15d46e2614ee296f3016d363dc)): ?>
<?php $component = $__componentOriginal636e3f15d46e2614ee296f3016d363dc; ?>
<?php unset($__componentOriginal636e3f15d46e2614ee296f3016d363dc); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2204861c4666ea1210f99ef4fed14180 = $component; } ?>
<?php $component = App\View\Components\Admin\Bar::resolve(['title' => 'Tipos'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Bar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2204861c4666ea1210f99ef4fed14180)): ?>
<?php $component = $__componentOriginal2204861c4666ea1210f99ef4fed14180; ?>
<?php unset($__componentOriginal2204861c4666ea1210f99ef4fed14180); ?>
<?php endif; ?>
    <div class="template-1 flex flex-wrap">
        <div class="contain w-3/5">
            <?php if(Session::has('success')): ?>
                <div class="alertas success">
                    <div class="box">
                        <p><?php echo \Session::get('success'); ?></p>
                    </div>
                </div>
                <script>
                    let alerta = document.querySelector('.alertas');
                    setTimeout(() => {
                        alerta.remove();
                    }, 2000);
                </script>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
                <div class="alertas error">
                    <div class="box">
                        <p><?php echo \Session::get('error'); ?></p>
                    </div>
                </div>
                <script>
                    let alerta = document.querySelector('.alertas');
                    setTimeout(() => {
                        alerta.remove();
                    }, 2000);
                </script>
            <?php endif; ?>
            <?php if($loop->isNotEmpty()): ?>
            <div class="table">
                <table id="tablr">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $loop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($i->name); ?></td>
                                <td>
                                    <div class="buttons">
                                        <a href="<?php echo e(route('manga_types.index')); ?>" class="mangaTypeDelete" data-id="<?php echo e($i->id); ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-trash" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                                <line x1="4" y1="7" x2="20" y2="7" />
                                                <line x1="10" y1="11" x2="10" y2="17" />
                                                <line x1="14" y1="11" x2="14" y2="17" />
                                                <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" />
                                                <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" />
                                            </svg>
                                        </a>
                                        <a href="<?php echo e(route('manga_types.index', ['id' => $i->id])); ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-pencil" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                                <path d="M4 20h4l10.5 -10.5a1.5 1.5 0 0 0 -4 -4l-10.5 10.5v4" />
                                                <line x1="13.5" y1="6.5" x2="17.5" y2="10.5" />
                                            </svg>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <div class="table">
                    <h4>No hay resultados</h4>
                </div>
            <?php endif; ?>
        </div>
        <aside class="side w-2/5">
            <div class="frmo">
                    <h2><?php echo e(isset($edit)? "Editar" : 'Crear'); ?> tipo</h2>
                <form action="<?php echo e(isset($edit)? route('manga_types.update', ['id' => $edit->id]) : route('manga_types.store')); ?>" class="form" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($edit)): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>
                    <div class="group">
                        <label>Nombre</label>
                        <input type="text" name="name" value="<?php echo e(isset($edit)? old('name', $edit->name) : ''); ?>">
                    </div>
                    <div class="group">
                        <label>Slug</label>
                        <input type="text" name="slug" value="<?php echo e(isset($edit)? old('slug', $edit->slug) : ''); ?>">
                    </div>
                    <div class="group">
                        <label>Description</label>
                        <textarea name="description" id="" cols="30" rows="4"><?php echo e(isset($edit)? old('description', $edit->description) : ''); ?></textarea>
                    </div>
                    
                    <div class="errores">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="botn success"><?php echo e(isset($edit)? "Actualizar" : 'Crear'); ?></button>
                </form>
            </div>
        </aside>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/admin/manga/type/index.blade.php ENDPATH**/ ?>