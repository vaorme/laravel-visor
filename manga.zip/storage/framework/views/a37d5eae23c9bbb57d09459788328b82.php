<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	<div class="main__wrap main__home">
		<div class="main__content">
			<?php if($slider->isNotEmpty()): ?>
				<section class="section home__slider">
					<div class="slide__box">
						<div class="swiper home__swiper">
							<div class="swiper-wrapper">
								<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php
										$rating = round($item->manga->rating->avg('rating'), 0, PHP_ROUND_HALF_DOWN);
									?>
									<div class="swiper-slide">
										<div class="slide__image" style="background-image: url(<?php echo e(asset('storage/'.$item->background)); ?>)"></div>
										<div class="slide__content">
											<div class="content__box">
												<div class="slide__logo">
													<a href="<?php echo e($item->manga->url()); ?>">
														<?php if(!empty($item->logo)): ?>
															<img src="<?php echo e(asset('storage/'.$item->logo)); ?>" alt="<?php echo e($item->manga->name); ?>">
														<?php else: ?>
															<span class="slide__name"><?php echo e($item->manga->name); ?></span>
														<?php endif; ?>
													</a>
												</div>
												<?php if($rating != 0): ?>
													<div class="manga__rating">
														<div class="rating__group">
															<input disabled="" class="rating__input rating__input--none" value="0" type="radio">
															<label aria-label="1 star" class="rating__label"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
															<input class="rating__input" value="1" type="radio" <?php echo e(($rating == 1)? 'checked': null); ?>>
															<label aria-label="2 stars" class="rating__label"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
															<input class="rating__input" value="2" type="radio" <?php echo e(($rating == 2)? 'checked': null); ?>>
															<label aria-label="3 stars" class="rating__label"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
															<input class="rating__input" value="3" type="radio" <?php echo e(($rating == 3)? 'checked': null); ?>>
															<label aria-label="4 stars" class="rating__label"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
															<input class="rating__input" value="4" type="radio" <?php echo e(($rating == 4)? 'checked': null); ?>>
															<label aria-label="5 stars" class="rating__label"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
															<input class="rating__input" value="5" type="radio" <?php echo e(($rating == 5)? 'checked': null); ?>>
														</div>
													</div>
												<?php endif; ?>
												<div class="slide__description">
													<p><?php echo e($item->description); ?></p>
												</div>
												<div class="slide__buttons">
													<a href="<?php echo e($item->manga->url()); ?>">Leer ahora</a>
												</div>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<div class="swiper-pagination"></div>
							<div class="swiper-button-prev"><i class="fa-solid fa-chevron-left"></i></div>
							<div class="swiper-button-next"><i class="fa-solid fa-chevron-right"></i></div>
						</div>
					</div>
				</section>
			<?php endif; ?>
			<?php
				$ad_2 = config('app.ads_2');
			?>
			<?php if($ad_2): ?>
				<div class="vealo">
					<?php echo $ad_2; ?>

				</div>
			<?php endif; ?>
			<section class="section most__viewed">
				<div class="section__title">
					<h2><span>mes</span> Más vistos</h2>
				</div>
				<div class="section__content">
					<div class="manga">
						<?php if(!$mostViewed->isEmpty()): ?>
							<div class="manga__list">
								<?php $__currentLoopData = $mostViewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if (isset($component)) { $__componentOriginal1404d421185503a5253acba2bee1c433 = $component; } ?>
<?php $component = App\View\Components\MangaLoopItem::resolve(['item' => $item] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('manga-loop-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MangaLoopItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1404d421185503a5253acba2bee1c433)): ?>
<?php $component = $__componentOriginal1404d421185503a5253acba2bee1c433; ?>
<?php unset($__componentOriginal1404d421185503a5253acba2bee1c433); ?>
<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						<?php else: ?>
							<div class="empty">No hay elementos para mostrar</div>
						<?php endif; ?>
					</div>
				</div>
			</section>
			<?php if($categories->isNotEmpty()): ?>
				<div class="home__categories">
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<section class="section section__cat">
							<div class="section__title">
								<h2><?php echo e($category->name); ?></h2>
							</div>
							<div class="section__content">
								<div class="manga">
									<div class="manga__list">
										<?php $__currentLoopData = $category->mangas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if (isset($component)) { $__componentOriginal1404d421185503a5253acba2bee1c433 = $component; } ?>
<?php $component = App\View\Components\MangaLoopItem::resolve(['item' => $item] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('manga-loop-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MangaLoopItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1404d421185503a5253acba2bee1c433)): ?>
<?php $component = $__componentOriginal1404d421185503a5253acba2bee1c433; ?>
<?php unset($__componentOriginal1404d421185503a5253acba2bee1c433); ?>
<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
						</section>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			<?php endif; ?>
		</div>
		<aside class="main__sidebar">
			<?php if(!$newChapters->isEmpty() && (isset($newChapters['manga']) || isset($newChapters['novel']))): ?>
				<h2 class="sidebar__title"><span>Semana</span> Nuevos capítulos</h2>
			<?php endif; ?>
			<?php if(!$newChapters->isEmpty() && isset($newChapters['manga'])): ?>
				<section class="section new_manga">
					<div class="section__title">
						<div class="section__type">Manga</div>
					</div>
					<div class="section__content">
						<div class="new__chapters">
							<?php $__currentLoopData = $newChapters['manga']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="new__chapters__item">
									<a href="<?php echo e($item->url()); ?>" class="new__chapters__link">
										<figure class="new__chapters__image">
											<?php
												$pathImage = 'storage/'.$item->manga->featured_image;
												$imageExtension = pathinfo($pathImage)["extension"];
												$img = ManipulateImage::cache(function($image) use ($item) {
													return $image->make('storage/'.$item->manga->featured_image)->fit(80, 68);
												}, 10, true);

												$img->response($imageExtension, 70);
												$base64 = 'data:image/' . $imageExtension . ';base64,' . base64_encode($img);
												
											?>
											<img src="<?php echo $base64; ?>" alt="<?php echo e($item->manga->name); ?>">
										</figure>
										<div class="new__chapters__content">
											<h6><?php echo e($item->name); ?></h6>
											<span class="new__chapters__chapter"><?php echo e($item->manga->name); ?></span>
											<span class="new__chapters__date"><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></span>
										</div>
										<div class="new__chapters__icon">
											<i class="fa-solid fa-book-open"></i>
										</div>
									</a>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</section>
			<?php endif; ?>
			<?php if($newChapters->isNotEmpty() && isset($newChapters['novel'])): ?>
				<section class="section new_novels">
					<div class="section__title">
						<div class="section__type">Novelas</div>
					</div>
					<div class="section__content">
						<div class="new__chapters">
							<?php $__currentLoopData = $newChapters['novel']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="new__chapters__item">
									<a href="<?php echo e($item->url()); ?>" class="new__chapters__link">
										<figure class="new__chapters__image">
											<?php
												$pathImage = 'storage/'.$item->manga->featured_image;
												$imageExtension = pathinfo($pathImage)["extension"];
												$img = ManipulateImage::cache(function($image) use ($item) {
													return $image->make('storage/'.$item->manga->featured_image)->fit(80, 68);
												}, 10, true);

												$img->response($imageExtension, 70);
												$base64 = 'data:image/' . $imageExtension . ';base64,' . base64_encode($img);
												
											?>
											<img src="<?php echo $base64; ?>" alt="<?php echo e($item->manga->name); ?>">
										</figure>
										<div class="new__chapters__content">
											<h6><?php echo e($item->name); ?></h6>
											<span class="new__chapters__chapter"><?php echo e($item->manga->name); ?></span>
											<span class="new__chapters__date"><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></span>
										</div>
										<div class="new__chapters__icon">
											<i class="fa-solid fa-book-open"></i>
										</div>
									</a>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</section>
			<?php endif; ?>
			<?php
				$ad_1 = config('app.ads_1');
			?>
			<?php if($ad_1): ?>
				<div class="vealo">
					<?php echo $ad_1; ?>

				</div>
			<?php endif; ?>
			<?php if($topmonth->isNotEmpty()): ?>
				<section class="section tops">
					<h2 class="sidebar__title"><span>TOP</span> Mensual</h2>
					<div class="section__content">
						<ul class="tops__list">
							<?php $__currentLoopData = $topmonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$count = ($key > 9)? $key : "0".($key + 1);
								?>
								<li class="list__item">
									<a href="<?php echo e($item->url()); ?>">
										<figure class="item__image">
											<?php
												$pathImage = 'storage/'.$item->featured_image;
												$imageExtension = pathinfo($pathImage)["extension"];
												$img = ManipulateImage::cache(function($image) use ($item) {
													return $image->make('storage/'.$item->featured_image)->fit(60, 54);
												}, 10, true);

												$img->response($imageExtension, 70);
												$base64 = 'data:image/' . $imageExtension . ';base64,' . base64_encode($img);
												
											?>
											<img src="<?php echo $base64; ?>" alt="<?php echo e($item->manga_name); ?>">
											<div class="item__count"><?php echo e($count); ?></div>
										</figure>
										<div class="item__info">
											<div class="item__name">
												<?php echo e(Str::limit($item->name, 28)); ?>

											</div>
											<div class="item__rate">
												<i class="fa-solid fa-star"></i>
												<span class="rate__count"><?php echo e(round($item->month_rating_avg_rating, 1, PHP_ROUND_HALF_DOWN)); ?></span>
											</div>
										</div>
									</a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				</section>
			<?php endif; ?>
			<?php
				$ad_3 = config('app.ads_3');
			?>
			<?php if($ad_3): ?>
				<div class="vealo">
					<?php echo $ad_3; ?>

				</div>
			<?php endif; ?>
		</aside>
	</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/home.blade.php ENDPATH**/ ?>