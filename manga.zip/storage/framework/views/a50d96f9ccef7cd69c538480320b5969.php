<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> SEO <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal636e3f15d46e2614ee296f3016d363dc = $component; } ?>
<?php $component = App\View\Components\Admin\Nav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Nav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <li class="<?php echo e((request()->is('controller/settings/ads')) ? 'active' : ''); ?>"><a href="<?php echo e(route('settings.ads.index')); ?>">Publicidad</a></li>
        <li class="<?php echo e((request()->is('controller/settings/seo')) ? 'active' : ''); ?>"><a href="<?php echo e(route('settings.seo.index')); ?>">SEO</a></li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal636e3f15d46e2614ee296f3016d363dc)): ?>
<?php $component = $__componentOriginal636e3f15d46e2614ee296f3016d363dc; ?>
<?php unset($__componentOriginal636e3f15d46e2614ee296f3016d363dc); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2204861c4666ea1210f99ef4fed14180 = $component; } ?>
<?php $component = App\View\Components\Admin\Bar::resolve(['title' => 'SEO'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Bar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2204861c4666ea1210f99ef4fed14180)): ?>
<?php $component = $__componentOriginal2204861c4666ea1210f99ef4fed14180; ?>
<?php unset($__componentOriginal2204861c4666ea1210f99ef4fed14180); ?>
<?php endif; ?>
    <div class="settings flex flex-wrap">
        <div class="contain w-full">
            <?php if(Session::has('success')): ?>
                <div class="alertas success">
                    <div class="box">
                        <p><?php echo \Session::get('success'); ?></p>
                    </div>
                </div>
                <script>
                    let alerta = document.querySelector('.alertas');
                    setTimeout(() => {
                        alerta.remove();
                    }, 2000);
                </script>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
                <div class="alertas error">
                    <div class="box">
                        <p><?php echo \Session::get('error'); ?></p>
                    </div>
                </div>
                <script>
                    let alerta = document.querySelector('.alertas');
                    setTimeout(() => {
                        alerta.remove();
                    }, 2000);
                </script>
            <?php endif; ?>
        </div>
        <section class="settings__contain w-full">
            <div class="frmo">
                <form action="<?php echo e(isset($setting)? route('settings.seo.update') : route('settings.seo.store')); ?>" class="form" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($setting)): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php else: ?>
                        <?php echo method_field('POST'); ?>
                    <?php endif; ?>
                    <div class="group">
                        <label>SEO título</label>
                        <input type="text" name="seo_title" value="<?php echo e(isset($setting)? old('seo_title', $setting->seo_title) : ''); ?>">
                    </div>
                    <div class="group">
                        <label>SEO descripción</label>
                        <textarea name="seo_description" cols="30" rows="4"><?php echo e(isset($setting)? old('seo_description', $setting->seo_description) : ''); ?></textarea>
                    </div>
                    <div class="group">
                        <label>SEO palabras clave</label>
                        <input type="text" name="seo_keywords" value="<?php echo e(isset($setting)? old('seo_keywords', $setting->seo_keywords) : ''); ?>">
                    </div>
                    <div class="group">
                        <label>SEO autor</label>
                        <input type="text" name="seo_author" value="<?php echo e(isset($setting)? old('seo_author', $setting->seo_author) : ''); ?>">
                    </div>
                    <div class="group">
                        <label>SEO asunto</label>
                        <input type="text" name="seo_subject" value="<?php echo e(isset($setting)? old('seo_subject', $setting->seo_subject) : ''); ?>">
                    </div>
                    <div class="group">
                        <label>SEO robots</label>
                        <input type="text" name="seo_robots" value="<?php echo e(isset($setting)? old('seo_robots', $setting->seo_robots) : ''); ?>">
                    </div>
                    
                    <div class="errores">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="botn success">Guardar</button>
                </form>
            </div>
        </section>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/admin/settings/seo.blade.php ENDPATH**/ ?>