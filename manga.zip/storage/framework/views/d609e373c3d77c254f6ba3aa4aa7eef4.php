<meta name="robots" content="Index,Follow">
<?php
    $seoDescription = config('app.seo_description');
    $seoAuthor = config('app.seo_author');
    $seoKeywords = config('app.seo_keywords');
    $seoSubject = config('app.seo_subject');
?>
<?php if($seoDescription): ?>
    <meta name="description" content="<?php echo e($seoDescription); ?>"/>
<?php endif; ?>
<?php if($seoAuthor): ?>
    <meta name="author" content="<?php echo e($seoAuthor); ?>" />
<?php endif; ?>
<?php if($seoKeywords): ?>
    <meta name="keywords" content="<?php echo e($seoKeywords); ?>">
<?php endif; ?>
<?php if($seoSubject): ?>
    <meta name="subject" content="<?php echo e($seoSubject); ?>">
<?php endif; ?><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/components/seo.blade.php ENDPATH**/ ?>