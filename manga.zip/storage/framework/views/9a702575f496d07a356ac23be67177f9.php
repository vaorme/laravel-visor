<nav class="nav">
    <ul class="flex gap-8">
        <?php echo e($slot); ?>

    </ul>
</nav><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/components/admin/nav.blade.php ENDPATH**/ ?>