<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e($title ?? config('app.title')); ?></title>
        <?php if (isset($component)) { $__componentOriginala2d9072d59b69a761b60324b3706ddf1 = $component; } ?>
<?php $component = App\View\Components\Seo::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('seo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Seo::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2d9072d59b69a761b60324b3706ddf1)): ?>
<?php $component = $__componentOriginala2d9072d59b69a761b60324b3706ddf1; ?>
<?php unset($__componentOriginala2d9072d59b69a761b60324b3706ddf1); ?>
<?php endif; ?>
        <link rel="shortcut icon" href="<?php echo e(config('app.favicon') ? asset('storage/'.config('app.favicon')): asset('storage/images/favicon.png')); ?>" type="image/png">

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/global.scss', 'resources/css/loreg.scss', 'resources/js/library.js']); ?>
        <?php
            $insertHead = config('app.head');
        ?>
        <?php if($insertHead): ?>
            <?php echo $insertHead; ?>

        <?php endif; ?>
    </head>
    <body>
        <?php
            $insertBody = config('app.body');
        ?>
        <?php if($insertBody): ?>
            <?php echo $insertBody; ?>

        <?php endif; ?>
        <div id="app">
            <div class="loreg">
                <?php echo e($slot); ?>

            </div>
        </div>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/loreg.js']); ?>
    </body>
</html>
<?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/layouts/loreg.blade.php ENDPATH**/ ?>