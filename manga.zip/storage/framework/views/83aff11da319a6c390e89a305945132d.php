<div class="manga__item">
    <div class="manga__cover">
        <a href="<?php echo e($item->url()); ?>" class="manga__link">
            <figure class="manga__image">
                <img src="<?php echo e($item->cover()); ?>" alt="<?php echo e($item->manga_name); ?>">
            </figure>
        </a>
        <?php if($item->rating->avg('rating')): ?>
            <div class="manga__ratings">
                <i class="fa-solid fa-star"></i>
                <div class="rating__avg"><?php echo e($item->rating->avg('rating')); ?></div>
            </div>
        <?php endif; ?>
        <div class="manga__terms">
            <?php if($item->demography): ?>
                <div class="manga__demography <?php echo e($item->demography->slug); ?>">
                    <a href="<?php echo e($item->demography->slug); ?>"><?php echo e($item->demography->name); ?></a>
                </div>
            <?php endif; ?>
            <?php if($item->type): ?>
                <div class="manga__type <?php echo e($item->type->slug); ?>">
                    <a href="<?php echo e($item->type->slug); ?>"><?php echo e($item->type->name); ?></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <h4 class="manga__title">
        <a href="<?php echo e($item->slug); ?>" class="manga__link"><?php echo e($item->name); ?></a>
    </h4>
</div><?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/components/manga-loop-item.blade.php ENDPATH**/ ?>