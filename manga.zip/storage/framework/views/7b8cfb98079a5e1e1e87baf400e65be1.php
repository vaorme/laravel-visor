<?php if (isset($component)) { $__componentOriginal77dc7f97cd15ecb13b15187aa7bada27 = $component; } ?>
<?php $component = App\View\Components\LoregLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loreg-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LoregLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Verificar correo <?php $__env->endSlot(); ?>
    <div class="box login">
        <div class="frmo">
            <div class="title">
                <h4 class="mb-2">Verificar correo</h4>
                <p><?php echo e(__('Gracias por registrarte! Antes de comenzar, ¿podría verificar su dirección de correo electrónico haciendo clic en el enlace que le acabamos de enviar? Si no recibiste el correo electrónico, con gusto te enviaremos otro.')); ?></p>
            </div>
            <?php if(session('status') == 'verification-link-sent'): ?>
                <div class="mb-4 text-center text-white p-2 bg-emerald-700">
                    <?php echo e(__('Se ha enviado un nuevo enlace de verificación a la dirección de correo electrónico que proporcionó durante el registro.')); ?>

                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                <?php echo csrf_field(); ?>
    
                <div class="group buttons text-center">
                    <button type="submit"><?php echo e(__('Resend Verification Email')); ?></button>
                </div>
            </form>
    
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
    
                <div class="group buttons alt-button text-center">
                    <button type="submit">
                        <?php echo e(__('Cerrar sesión')); ?>

                    </button>
                </div>
            </form>
        </div>
        <div class="banner"></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal77dc7f97cd15ecb13b15187aa7bada27)): ?>
<?php $component = $__componentOriginal77dc7f97cd15ecb13b15187aa7bada27; ?>
<?php unset($__componentOriginal77dc7f97cd15ecb13b15187aa7bada27); ?>
<?php endif; ?>
<?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>