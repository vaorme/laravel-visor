<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e($title ?? 'Controller'); ?></title>
        <link rel="shortcut icon" href="<?php echo e(config('app.favicon') ? asset('storage/'.config('app.favicon')): asset('storage/images/favicon.png')); ?>" type="image/png">
        <!-- Styles -->
        <link href="<?php echo e(Vite::asset('resources/css/web/tom-select.css')); ?>" rel="stylesheet">
        <!-- Scripts -->
        <script type="module" src="<?php echo e(Vite::asset('resources/js/admin/library.js')); ?>"></script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/global.scss', 'resources/css/admin/admin.scss']); ?>
        
        <script src="<?php echo e(asset('storage/assets/js/tom-select.js')); ?>"></script>
        <?php if(Route::is(['slider.index'])): ?>
            <script type="module" src="<?php echo e(Vite::asset('resources/js/admin/slider.js')); ?>"></script>
            <link href="<?php echo e(Vite::asset('resources/css/admin/slider.scss')); ?>" rel="stylesheet">
        <?php endif; ?>
        <?php if(Route::is(['settings.index']) || Route::is(['settings.ads.index']) || Route::is(['settings.seo.index'])): ?>
            <link href="<?php echo e(Vite::asset('resources/css/admin/settings.scss')); ?>" rel="stylesheet">
        <?php endif; ?>
    </head>
    <body>
        <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
        <div id="app">
            <?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
            <main class="main flex">
                <?php if (isset($component)) { $__componentOriginald417e0638ea790d8a6d32bd501701baa = $component; } ?>
<?php $component = App\View\Components\Admin\Aside::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Aside::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald417e0638ea790d8a6d32bd501701baa)): ?>
<?php $component = $__componentOriginald417e0638ea790d8a6d32bd501701baa; ?>
<?php unset($__componentOriginald417e0638ea790d8a6d32bd501701baa); ?>
<?php endif; ?>
                <div class="box">
                    <?php echo e($slot); ?>

                </div>
            </main>
            <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
        </div>
        <script type="module" src="<?php echo e(Vite::asset('resources/js/admin/admin.js')); ?>"></script>
        <?php if(Route::is(['settings.index']) || Route::is(['settings.ads.index']) || Route::is(['settings.seo.index'])): ?>
            <script type="module" src="<?php echo e(Vite::asset('resources/js/admin/settings.js')); ?>"></script>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH D:\Spaces\LARAVEL\manga\resources\views/layouts/admin.blade.php ENDPATH**/ ?>