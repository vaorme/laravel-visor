import '../library';

document.addEventListener('DOMContentLoaded', function(){
    
});