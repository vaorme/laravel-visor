<nav class="nav">
    <ul class="flex gap-8">
        {{ $slot }}
    </ul>
</nav>